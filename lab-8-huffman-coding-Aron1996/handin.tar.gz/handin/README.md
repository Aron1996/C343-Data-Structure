# Huffman Coding

For this project, you will implement Huffman's greedy algorithm 
for text compression and then write a brief report containing 
the results of running your code on three books.
Complete the TODO's in `HuffmanTree.java` file and `Driver.java`.