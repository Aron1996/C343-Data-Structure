# Lab 2: Linked Lists and the Sequence ADT

Implement and test all the methods in the `ListIter` and `LinkedList`
classes in the file LinkedList.java.  The methods currently just throw
an exception. Replace that behavior with the correct behavior.  The
`test/sequences/LinkedListTest` class performs several tests that
should pass if you have correctly implemented the methods. Add
several more tests of your own.


